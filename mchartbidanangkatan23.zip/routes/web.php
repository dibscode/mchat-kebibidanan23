<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BabyController;

Route::get('/', [BabyController::class, 'index'])->name('bayi.index');
Route::resource('bayi', BabyController::class);
Route::post('/baby/store', [BabyController::class, 'store'])->name('baby.store');
